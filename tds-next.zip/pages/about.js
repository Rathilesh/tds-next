import Layout from '../components/layouts/layout'

export default function About() {
  return (
    <Layout title="About us">
      <div>About us</div>
    </Layout>
  )
}